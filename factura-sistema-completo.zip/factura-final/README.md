# Actividad 1.2.2 – DSY1106 Desarrollo Fullstack III
## Microservicio: factura-service

---

## 1. Selección de Herramienta y Justificación

**Herramienta elegida: Docker**

| Criterio | Justificación |
|---|---|
| **Eficiencia** | Contenedor ligero (~200MB) vs máquina virtual (varios GB). Inicio en segundos. |
| **Escalabilidad** | Fácilmente replicable con `docker-compose --scale factura-service=3` para múltiples instancias. |
| **Mantenimiento** | El `Dockerfile` multi-etapa separa compilación de ejecución, reduciendo el tamaño final. |
| **Portabilidad** | Funciona igual en cualquier máquina que tenga Docker, sin configurar Java ni Maven. |
| **Variables de entorno** | Puerto, IVA y credenciales configurables sin tocar el código fuente. |

---

## 2. Comandos para ejecutar

### Opción A – Con Docker Compose (recomendado)
```bash
# Construir y levantar
docker-compose up --build

# Ver logs
docker-compose logs -f

# Detener
docker-compose down
```

### Opción B – Solo Docker
```bash
# Construir la imagen
docker build -t factura-service:1.0 .

# Ejecutar el contenedor con variables de entorno
docker run -d \
  --name factura-service \
  -p 8081:8081 \
  -e IVA_PORCENTAJE=19 \
  -e SHOW_SQL=true \
  factura-service:1.0

# Ver logs
docker logs -f factura-service

# Detener y eliminar
docker stop factura-service && docker rm factura-service
```

---

## 3. Endpoints disponibles

| Método | URL | Descripción |
|--------|-----|-------------|
| `GET`  | `/api/facturas/health` | Health check |
| `POST` | `/api/facturas` | Crear factura |
| `GET`  | `/api/facturas` | Listar todas |
| `GET`  | `/api/facturas/{id}` | Obtener por ID |

---

## 4. Ejemplo de request (Postman)

**POST** `http://localhost:8081/api/facturas`
```json
{
  "clienteNombre": "Empresa Ejemplo SpA",
  "clienteRut": "76.543.210-K",
  "clienteEmail": "contacto@ejemplo.cl",
  "items": [
    { "descripcion": "Desarrollo de software", "cantidad": 10, "precioUnitario": 150000 },
    { "descripcion": "Soporte técnico",        "cantidad": 5,  "precioUnitario": 80000  }
  ]
}
```

**Respuesta esperada (201 Created):**
```json
{
  "id": 1,
  "numeroFactura": "FAC-1711234567890",
  "clienteNombre": "Empresa Ejemplo SpA",
  "clienteRut": "76.543.210-K",
  "estado": "PENDIENTE",
  "items": [...],
  "subtotal": 1900000,
  "iva": 361000,
  "total": 2261000,
  "fechaCreacion": "2026-03-30 12:00:00"
}
```

---

## 5. Patrón de resiliencia implementado

**Manejo centralizado de errores** (`GlobalExceptionHandler`):
- Errores de validación → `400 Bad Request` con detalle por campo
- Recurso no encontrado → `404 Not Found` con mensaje claro
- Error inesperado → `500 Internal Server Error` sin exponer info sensible

---

## 6. Variables de entorno configurables

| Variable | Default | Descripción |
|---|---|---|
| `SERVER_PORT` | `8081` | Puerto del servicio |
| `IVA_PORCENTAJE` | `19` | Porcentaje IVA aplicado |
| `SHOW_SQL` | `false` | Mostrar queries SQL en logs |
| `DB_USER` | `sa` | Usuario base de datos |
| `DB_PASSWORD` | `` | Contraseña base de datos |
