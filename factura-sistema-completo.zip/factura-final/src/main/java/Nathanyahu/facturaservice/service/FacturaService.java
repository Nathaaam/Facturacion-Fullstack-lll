package Nathanyahu.facturaservice.service;

import Nathanyahu.facturaservice.dto.FacturaDTO;
import Nathanyahu.facturaservice.model.Factura;
import Nathanyahu.facturaservice.model.ItemFactura;
import Nathanyahu.facturaservice.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FacturaService {

    private final FacturaRepository repo;

    // IVA viene de variable de entorno (application.properties -> Docker env)
    @Value("${app.iva.porcentaje:19}")
    private int ivaPorcentaje;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // ── CREAR ────────────────────────────────────────────────────────────────
    @Transactional
    public FacturaDTO.FacturaResponse crearFactura(FacturaDTO.CrearFacturaRequest req) {
        log.info("Creando factura para cliente: {}", req.getClienteNombre());

        // 1. Crear la factura base (sin items todavía)
        Factura factura = Factura.builder()
                .clienteNombre(req.getClienteNombre())
                .clienteRut(req.getClienteRut())
                .clienteEmail(req.getClienteEmail())
                .observaciones(req.getObservaciones())
                .build();

        // 2. Mapear ítems y calcular subtotales
        List<ItemFactura> items = req.getItems() == null ? new ArrayList<>() :
                req.getItems().stream().map(i -> {
                    ItemFactura item = ItemFactura.builder()
                            .factura(factura)
                            .descripcion(i.getDescripcion())
                            .cantidad(i.getCantidad())
                            .precioUnitario(i.getPrecioUnitario())
                            .build();
                    item.calcularSubtotal();
                    return item;
                }).collect(Collectors.toList());

        factura.setItems(items);

        // 3. Calcular totales con IVA configurable
        BigDecimal subtotal = items.stream()
                .map(ItemFactura::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal factorIva = BigDecimal.valueOf(ivaPorcentaje)
                .divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP);
        BigDecimal iva   = subtotal.multiply(factorIva).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = subtotal.add(iva).setScale(2, RoundingMode.HALF_UP);

        factura.setSubtotal(subtotal.setScale(2, RoundingMode.HALF_UP));
        factura.setIva(iva);
        factura.setTotal(total);

        // 4. Persistir todo en cascada
        Factura resultado = repo.save(factura);
        log.info("Factura {} creada. Total: {}", resultado.getNumeroFactura(), total);

        return toResponse(resultado);
    }

    // ── LISTAR ───────────────────────────────────────────────────────────────
    public List<FacturaDTO.FacturaResponse> listar() {
        return repo.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    // ── OBTENER POR ID ───────────────────────────────────────────────────────
    public FacturaDTO.FacturaResponse obtener(Long id) {
        Factura f = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada: " + id));
        return toResponse(f);
    }

    // ── MAPEO ────────────────────────────────────────────────────────────────
    private FacturaDTO.FacturaResponse toResponse(Factura f) {
        List<FacturaDTO.ItemResponse> items = f.getItems() == null ? List.of() :
                f.getItems().stream().map(i -> FacturaDTO.ItemResponse.builder()
                        .id(i.getId())
                        .descripcion(i.getDescripcion())
                        .cantidad(i.getCantidad())
                        .precioUnitario(i.getPrecioUnitario())
                        .subtotal(i.getSubtotal())
                        .build()).collect(Collectors.toList());

        return FacturaDTO.FacturaResponse.builder()
                .id(f.getId())
                .numeroFactura(f.getNumeroFactura())
                .clienteNombre(f.getClienteNombre())
                .clienteRut(f.getClienteRut())
                .clienteEmail(f.getClienteEmail())
                .estado(f.getEstado().name())
                .items(items)
                .subtotal(f.getSubtotal())
                .iva(f.getIva())
                .total(f.getTotal())
                .observaciones(f.getObservaciones())
                .fechaCreacion(f.getFechaCreacion() != null
                        ? f.getFechaCreacion().format(FMT) : null)
                .build();
    }
}
