package Nathanyahu.facturaservice.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "facturas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Factura {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String numeroFactura;

    @Column(nullable = false)
    private String clienteNombre;

    @Column(nullable = false)
    private String clienteRut;

    private String clienteEmail;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private EstadoFactura estado = EstadoFactura.PENDIENTE;

    @OneToMany(mappedBy = "factura", cascade = CascadeType.ALL,
               fetch = FetchType.EAGER, orphanRemoval = true)
    @Builder.Default
    private List<ItemFactura> items = new ArrayList<>();

    private BigDecimal subtotal;
    private BigDecimal iva;
    private BigDecimal total;

    private String observaciones;

    @Column(updatable = false)
    private LocalDateTime fechaCreacion;

    private LocalDateTime fechaActualizacion;

    @PrePersist
    protected void onCreate() {
        fechaCreacion      = LocalDateTime.now();
        fechaActualizacion = LocalDateTime.now();
        if (numeroFactura == null) {
            numeroFactura = "FAC-" + System.currentTimeMillis();
        }
    }

    @PreUpdate
    protected void onUpdate() {
        fechaActualizacion = LocalDateTime.now();
    }

    public enum EstadoFactura {
        PENDIENTE, PAGADA, ANULADA, VENCIDA
    }
}
