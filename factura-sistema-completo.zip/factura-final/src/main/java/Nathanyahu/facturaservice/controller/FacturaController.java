package Nathanyahu.facturaservice.controller;

import Nathanyahu.facturaservice.dto.FacturaDTO;
import Nathanyahu.facturaservice.service.FacturaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FacturaController {

    private final FacturaService service;

    // POST /api/facturas  → Crear factura
    @PostMapping
    public ResponseEntity<FacturaDTO.FacturaResponse> crear(
            @Valid @RequestBody FacturaDTO.CrearFacturaRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.crearFactura(req));
    }

    // GET /api/facturas  → Listar todas
    @GetMapping
    public ResponseEntity<List<FacturaDTO.FacturaResponse>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    // GET /api/facturas/{id}  → Obtener por ID
    @GetMapping("/{id}")
    public ResponseEntity<FacturaDTO.FacturaResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(service.obtener(id));
    }

    // GET /api/facturas/health  → Health check (útil para verificar en Docker)
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status",   "UP",
                "servicio", "factura-service",
                "version",  "1.0.0"
        ));
    }
}
