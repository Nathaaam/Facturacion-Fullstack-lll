package Nathanyahu.facturaservice.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.util.List;

public class FacturaDTO {

    // ── REQUEST: lo que llega al crear una factura ──────────────────────────
    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CrearFacturaRequest {

        @NotBlank(message = "El nombre del cliente es obligatorio")
        private String clienteNombre;

        @NotBlank(message = "El RUT es obligatorio")
        private String clienteRut;

        private String clienteEmail;

        @NotEmpty(message = "Debe incluir al menos un ítem")
        private List<ItemRequest> items;

        private String observaciones;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ItemRequest {

        @NotBlank(message = "La descripción es obligatoria")
        private String descripcion;

        @NotNull @Min(1)
        private Integer cantidad;

        @NotNull @DecimalMin("0.01")
        private BigDecimal precioUnitario;
    }

    // ── RESPONSE: lo que devuelve el servicio ───────────────────────────────
    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class FacturaResponse {
        private Long id;
        private String numeroFactura;
        private String clienteNombre;
        private String clienteRut;
        private String clienteEmail;
        private String estado;
        private List<ItemResponse> items;
        private BigDecimal subtotal;
        private BigDecimal iva;
        private BigDecimal total;
        private String observaciones;
        private String fechaCreacion;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ItemResponse {
        private Long id;
        private String descripcion;
        private Integer cantidad;
        private BigDecimal precioUnitario;
        private BigDecimal subtotal;
    }
}
