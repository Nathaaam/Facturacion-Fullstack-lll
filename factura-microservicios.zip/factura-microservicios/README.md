# Factura Microservicios

Arquitectura CQRS (Command / Query) con dos microservicios Spring Boot separados, orquestados con Docker Compose y un API Gateway nginx.

---

## Arquitectura

```
Browser
   │
   └──► nginx :80  (API Gateway + Frontend)
              │
              ├── GET  /api/facturas/**  ──► factura-query-service   :8081
              │
              └── POST /api/facturas     ──► factura-command-service :8082
                   PUT  /api/facturas/{id}
```

### Servicios

| Servicio                  | Puerto | Responsabilidad              |
|---------------------------|--------|------------------------------|
| `factura-query-service`   | 8081   | Listar y obtener facturas    |
| `factura-command-service` | 8082   | Crear y modificar facturas   |
| `frontend` (nginx)        | 80     | Gateway + interfaz web       |

---

## Endpoints

### Query Service (GET)
| Método | Ruta                    | Descripción           |
|--------|-------------------------|-----------------------|
| GET    | `/api/facturas`         | Listar todas          |
| GET    | `/api/facturas/{id}`    | Obtener por ID        |
| GET    | `/api/facturas/health`  | Health check          |

### Command Service (POST / PUT)
| Método | Ruta                    | Descripción           |
|--------|-------------------------|-----------------------|
| POST   | `/api/facturas`         | Crear factura         |
| PUT    | `/api/facturas/{id}`    | Modificar factura     |
| GET    | `/api/facturas/health`  | Health check          |

#### Body para crear (POST)
```json
{
  "clienteNombre": "Juan Pérez",
  "clienteRut": "12.345.678-9",
  "clienteEmail": "juan@example.com",
  "observaciones": "Pago a 30 días",
  "items": [
    {
      "descripcion": "Servicio de diseño",
      "cantidad": 2,
      "precioUnitario": 50000
    }
  ]
}
```

#### Body para modificar (PUT) — todos los campos son opcionales
```json
{
  "clienteNombre": "Juan Pérez Actualizado",
  "estado": "PAGADA",
  "items": [
    {
      "descripcion": "Servicio actualizado",
      "cantidad": 3,
      "precioUnitario": 60000
    }
  ]
}
```

#### Estados disponibles
`PENDIENTE` · `PAGADA` · `ANULADA` · `VENCIDA`

---

## Levantar el proyecto

```bash
docker compose up --build
```

Accesos:
- Frontend: http://localhost
- Query API: http://localhost:8081/api/facturas
- Command API: http://localhost:8082/api/facturas
- H2 Console (query): http://localhost:8081/h2-console
- H2 Console (command): http://localhost:8082/h2-console

---

## Estructura de carpetas

```
factura-microservicios/
├── docker-compose.yml
├── nginx.conf
├── factura-query-service/         ← Solo lectura (GET)
│   ├── Dockerfile
│   ├── pom.xml
│   └── src/main/java/Nathanyahu/factura/
│       ├── controller/FacturaQueryController.java
│       ├── service/FacturaQueryService.java
│       ├── repository/FacturaRepository.java
│       ├── model/{Factura, ItemFactura}.java
│       ├── dto/FacturaDTO.java
│       └── config/GlobalExceptionHandler.java
└── factura-command-service/       ← Escritura (POST / PUT)
    ├── Dockerfile
    ├── pom.xml
    └── src/main/java/Nathanyahu/factura/
        ├── controller/FacturaCommandController.java
        ├── service/FacturaCommandService.java
        ├── repository/FacturaRepository.java
        ├── model/{Factura, ItemFactura}.java
        ├── dto/FacturaDTO.java
        └── config/GlobalExceptionHandler.java
```

---

## Nota sobre la base de datos

Cada servicio usa H2 en memoria de forma independiente. Esto es correcto para desarrollo y para demostrar la separación de microservicios.

Para producción se recomienda usar una base de datos externa compartida (PostgreSQL o MySQL). Solo hay que cambiar en ambos `application.properties`:

```properties
spring.datasource.url=jdbc:postgresql://db-host:5432/facturadb
spring.datasource.driver-class-name=org.postgresql.Driver
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

Y agregar el servicio de base de datos en `docker-compose.yml`.
