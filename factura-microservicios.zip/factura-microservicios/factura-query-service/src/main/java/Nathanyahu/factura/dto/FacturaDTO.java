package Nathanyahu.factura.dto;

import lombok.*;
import java.math.BigDecimal;
import java.util.List;

public class FacturaDTO {

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class FacturaResponse {
        private Long id;
        private String numeroFactura;
        private String clienteNombre;
        private String clienteRut;
        private String clienteEmail;
        private String estado;
        private List<ItemResponse> items;
        private BigDecimal subtotal;
        private BigDecimal iva;
        private BigDecimal total;
        private String observaciones;
        private String fechaCreacion;
    }

    @Data @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ItemResponse {
        private Long id;
        private String descripcion;
        private Integer cantidad;
        private BigDecimal precioUnitario;
        private BigDecimal subtotal;
    }
}
