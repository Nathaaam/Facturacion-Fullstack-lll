package Nathanyahu.factura.service;

import Nathanyahu.factura.dto.FacturaDTO;
import Nathanyahu.factura.model.Factura;
import Nathanyahu.factura.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;


@Service
@RequiredArgsConstructor
@Slf4j
public class FacturaQueryService {

    private final FacturaRepository repo;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public List<FacturaDTO.FacturaResponse> listar() {
        log.info("Listando todas las facturas");
        return repo.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    // ── OBTENER POR ID ───────────────────────────────────────────────────────
    public FacturaDTO.FacturaResponse obtener(Long id) {
        log.info("Obteniendo factura id={}", id);
        Factura f = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada: " + id));
        return toResponse(f);
    }

    // ── MAPEO ────────────────────────────────────────────────────────────────
    private FacturaDTO.FacturaResponse toResponse(Factura f) {
        List<FacturaDTO.ItemResponse> items = f.getItems() == null ? List.of() :
                f.getItems().stream().map(i -> FacturaDTO.ItemResponse.builder()
                        .id(i.getId())
                        .descripcion(i.getDescripcion())
                        .cantidad(i.getCantidad())
                        .precioUnitario(i.getPrecioUnitario())
                        .subtotal(i.getSubtotal())
                        .build()).collect(Collectors.toList());

        return FacturaDTO.FacturaResponse.builder()
                .id(f.getId())
                .numeroFactura(f.getNumeroFactura())
                .clienteNombre(f.getClienteNombre())
                .clienteRut(f.getClienteRut())
                .clienteEmail(f.getClienteEmail())
                .estado(f.getEstado().name())
                .items(items)
                .subtotal(f.getSubtotal())
                .iva(f.getIva())
                .total(f.getTotal())
                .observaciones(f.getObservaciones())
                .fechaCreacion(f.getFechaCreacion() != null
                        ? f.getFechaCreacion().format(FMT) : null)
                .build();
    }
}
