package Nathanyahu.factura.controller;

import Nathanyahu.factura.dto.FacturaDTO;
import Nathanyahu.factura.service.FacturaQueryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador de LECTURA.
 * Expone únicamente endpoints GET para consultar facturas.
 */
@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FacturaQueryController {

    private final FacturaQueryService service;

    // GET /api/facturas  → Listar todas
    @GetMapping
    public ResponseEntity<List<FacturaDTO.FacturaResponse>> listar() {
        return ResponseEntity.ok(service.listar());
    }

    // GET /api/facturas/{id}  → Obtener por ID
    @GetMapping("/{id}")
    public ResponseEntity<FacturaDTO.FacturaResponse> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(service.obtener(id));
    }

    // GET /api/facturas/health
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status",    "UP",
                "servicio",  "factura-query-service",
                "version",   "1.0.0",
                "tipo",      "READ"
        ));
    }
}
