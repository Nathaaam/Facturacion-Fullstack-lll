package Nathanyahu.factura.controller;

import Nathanyahu.factura.dto.FacturaDTO;
import Nathanyahu.factura.service.FacturaCommandService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Controlador de ESCRITURA.
 * Expone endpoints POST y PUT para crear y modificar facturas.
 */
@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FacturaCommandController {

    private final FacturaCommandService service;

    // POST /api/facturas  → Crear nueva factura
    @PostMapping
    public ResponseEntity<FacturaDTO.FacturaResponse> crear(
            @Valid @RequestBody FacturaDTO.CrearFacturaRequest req) {
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.crearFactura(req));
    }

    // PUT /api/facturas/{id}  → Modificar factura existente
    @PutMapping("/{id}")
    public ResponseEntity<FacturaDTO.FacturaResponse> modificar(
            @PathVariable Long id,
            @RequestBody FacturaDTO.ModificarFacturaRequest req) {
        return ResponseEntity.ok(service.modificarFactura(id, req));
    }

    // GET /api/facturas/health
    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status",   "UP",
                "servicio", "factura-command-service",
                "version",  "1.0.0",
                "tipo",     "WRITE"
        ));
    }
}
