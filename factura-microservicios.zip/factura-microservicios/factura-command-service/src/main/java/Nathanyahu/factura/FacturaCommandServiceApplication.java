package Nathanyahu.factura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacturaCommandServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(FacturaCommandServiceApplication.class, args);
    }
}
