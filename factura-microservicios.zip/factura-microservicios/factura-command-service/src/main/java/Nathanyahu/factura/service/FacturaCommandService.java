package Nathanyahu.factura.service;

import Nathanyahu.factura.dto.FacturaDTO;
import Nathanyahu.factura.model.Factura;
import Nathanyahu.factura.model.ItemFactura;
import Nathanyahu.factura.repository.FacturaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Servicio de ESCRITURA (Command).
 * Maneja la creación y modificación de facturas.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FacturaCommandService {

    private final FacturaRepository repo;

    @Value("${app.iva.porcentaje:19}")
    private int ivaPorcentaje;

    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    // ── CREAR ────────────────────────────────────────────────────────────────
    @Transactional
    public FacturaDTO.FacturaResponse crearFactura(FacturaDTO.CrearFacturaRequest req) {
        log.info("Creando factura para cliente: {}", req.getClienteNombre());

        Factura factura = Factura.builder()
                .clienteNombre(req.getClienteNombre())
                .clienteRut(req.getClienteRut())
                .clienteEmail(req.getClienteEmail())
                .observaciones(req.getObservaciones())
                .build();

        List<ItemFactura> items = req.getItems() == null ? new ArrayList<>() :
                req.getItems().stream().map(i -> {
                    ItemFactura item = ItemFactura.builder()
                            .factura(factura)
                            .descripcion(i.getDescripcion())
                            .cantidad(i.getCantidad())
                            .precioUnitario(i.getPrecioUnitario())
                            .build();
                    item.calcularSubtotal();
                    return item;
                }).collect(Collectors.toList());

        factura.setItems(items);
        calcularTotales(factura);

        Factura resultado = repo.save(factura);
        log.info("Factura {} creada. Total: {}", resultado.getNumeroFactura(), resultado.getTotal());
        return toResponse(resultado);
    }

    // ── MODIFICAR ────────────────────────────────────────────────────────────
    @Transactional
    public FacturaDTO.FacturaResponse modificarFactura(Long id, FacturaDTO.ModificarFacturaRequest req) {
        log.info("Modificando factura id={}", id);

        Factura factura = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Factura no encontrada: " + id));

        // Actualizar campos de cliente si vienen en el request
        if (req.getClienteNombre() != null && !req.getClienteNombre().isBlank()) {
            factura.setClienteNombre(req.getClienteNombre());
        }
        if (req.getClienteRut() != null && !req.getClienteRut().isBlank()) {
            factura.setClienteRut(req.getClienteRut());
        }
        if (req.getClienteEmail() != null) {
            factura.setClienteEmail(req.getClienteEmail());
        }
        if (req.getObservaciones() != null) {
            factura.setObservaciones(req.getObservaciones());
        }

        // Cambiar estado si se especifica
        if (req.getEstado() != null && !req.getEstado().isBlank()) {
            try {
                factura.setEstado(Factura.EstadoFactura.valueOf(req.getEstado().toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw new RuntimeException("Estado inválido: " + req.getEstado()
                        + ". Valores válidos: PENDIENTE, PAGADA, ANULADA, VENCIDA");
            }
        }

        // Reemplazar ítems si se envían
        if (req.getItems() != null && !req.getItems().isEmpty()) {
            factura.getItems().clear();
            List<ItemFactura> nuevosItems = req.getItems().stream().map(i -> {
                ItemFactura item = ItemFactura.builder()
                        .factura(factura)
                        .descripcion(i.getDescripcion())
                        .cantidad(i.getCantidad())
                        .precioUnitario(i.getPrecioUnitario())
                        .build();
                item.calcularSubtotal();
                return item;
            }).collect(Collectors.toList());
            factura.getItems().addAll(nuevosItems);
            calcularTotales(factura);
        }

        Factura resultado = repo.save(factura);
        log.info("Factura {} modificada.", resultado.getNumeroFactura());
        return toResponse(resultado);
    }

    // ── CALCULAR TOTALES ─────────────────────────────────────────────────────
    private void calcularTotales(Factura factura) {
        BigDecimal subtotal = factura.getItems().stream()
                .map(ItemFactura::getSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal factorIva = BigDecimal.valueOf(ivaPorcentaje)
                .divide(BigDecimal.valueOf(100), 4, RoundingMode.HALF_UP);
        BigDecimal iva   = subtotal.multiply(factorIva).setScale(2, RoundingMode.HALF_UP);
        BigDecimal total = subtotal.add(iva).setScale(2, RoundingMode.HALF_UP);

        factura.setSubtotal(subtotal.setScale(2, RoundingMode.HALF_UP));
        factura.setIva(iva);
        factura.setTotal(total);
    }

    // ── MAPEO ────────────────────────────────────────────────────────────────
    private FacturaDTO.FacturaResponse toResponse(Factura f) {
        List<FacturaDTO.ItemResponse> items = f.getItems() == null ? List.of() :
                f.getItems().stream().map(i -> FacturaDTO.ItemResponse.builder()
                        .id(i.getId())
                        .descripcion(i.getDescripcion())
                        .cantidad(i.getCantidad())
                        .precioUnitario(i.getPrecioUnitario())
                        .subtotal(i.getSubtotal())
                        .build()).collect(Collectors.toList());

        return FacturaDTO.FacturaResponse.builder()
                .id(f.getId())
                .numeroFactura(f.getNumeroFactura())
                .clienteNombre(f.getClienteNombre())
                .clienteRut(f.getClienteRut())
                .clienteEmail(f.getClienteEmail())
                .estado(f.getEstado().name())
                .items(items)
                .subtotal(f.getSubtotal())
                .iva(f.getIva())
                .total(f.getTotal())
                .observaciones(f.getObservaciones())
                .fechaCreacion(f.getFechaCreacion() != null
                        ? f.getFechaCreacion().format(FMT) : null)
                .build();
    }
}
