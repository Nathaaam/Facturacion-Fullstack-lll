package _8.facturacion;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/facturas")
public class FacturaController {
    
    private List<Facturacion> historialFacturas = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<Facturacion>> obtenerFacturas() {
        return new ResponseEntity<>(historialFacturas, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Facturacion> generarFactura(@RequestBody Facturacion nuevaFactura) {

        nuevaFactura.setId(UUID.randomUUID().toString());
        nuevaFactura.setFechaEmision(LocalDateTime.now());
        nuevaFactura.setEstado("EMITIDA");

        historialFacturas.add(nuevaFactura);

        return new ResponseEntity<>(nuevaFactura, HttpStatus.CREATED);
    }
}
